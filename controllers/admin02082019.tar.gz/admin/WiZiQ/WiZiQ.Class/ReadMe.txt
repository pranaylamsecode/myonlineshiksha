getting started is very easy

you can start with 
WiZiQService.php 

just change following values  in WiZiQService.php 


$access_key="your access key";
$secretAcessKey="your secret key";
$webServiceUrl="http://class.api.wiziq.com/";

