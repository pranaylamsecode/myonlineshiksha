<script src="<?php echo base_url()?>public/js/ajaxfileupload.js"></script>
<link rel="stylesheet" type="text/css" href="/public/css/courses_css/courses_form.css">
<link rel="stylesheet" type="text/css" href="/public/css/category_css/category.css"> 
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/plyr/3.4.8/plyr.css">
<!-- 
  <link rel="preload" as="font" crossorigin type="font/woff2" href="<?php echo base_url() ?>public/js/plyr-io/gordita-medium.woff2">
  <link rel="preload" as="font" crossorigin type="font/woff2" href="<?php echo base_url() ?>public/js/plyr-io/gordita-bold.woff2">  -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/plyr/3.4.8/plyr.js"></script>

<script>
  jQuery(document).ready(
  function()
  {
     jQuery('#description').redactor(); 

     jQuery('.redactor-editor').css({'overflow':'scroll','max-height':'100px'});
  });

  function check_name(fldid){

  var name = jQuery("#"+fldid).val();  
  
  
    $.ajax({



        type: "post",
        <?php 
        if ($updType != 'edit')
        {
         ?>        
        url: "<?php echo base_url('admin/medias/checkname'); ?>",
    <?php }
    else
      {
        ?>
         url: "<?php echo base_url() ?>admin/medias/checknamedit/<?php echo $this->uri->segment(4); ?>",
        <?php
      }
        ?>
        data: {name:name},

        success: function(msg)

        {
          
         
          
      /*$('body,html').animate({ scrollTop: 0 }, 200); */

            if(msg == 'success')

            {

                
                $("#ajax").css({"color": "red","padding-left": "300px"});
                $("#ajax").html('Already Exist');
                jQuery("#"+fldid).val('');



               /* $("#submitbutton").html('<input type="button" name="button" id="button" value="<?php echo 'POST'; ?>" onclick="create_blog()" class="stbutton"/>'); */

            }

            else

            {
                $("#ajax").css({"color": "green","padding-left": "300px"});
                $("#ajax").html('Available');


            }

        }



    });

}
</script>
<script type="text/javascript">

//jQuery(document).ready(function($) {

//$('#title').val()
var $ = jQuery;
$(function() {



   $('#file_i,#file_v,#file_a,#file_d,#file_f').on('change',function(e) {



   var ftpfileoptions;



   var ftpfilearray;



   switch($('select#type').val()){



     case 'image': var fldtype='i';



    break;



     case 'video': var fldtype='v';



    break;



     case 'audio': var fldtype='a';



    break;



     case 'docs': var fldtype='d';



    break;



     case 'file': var fldtype='f';



    break;



   }


   e.preventDefault();
   

      return false;

   });
});

//});
</script>


<script type="text/javascript">
window.onload = function() {
  var local_upload = document.getElementById("source_local_v2").checked;

    if(local_upload == true){
     var local_val = document.getElementById("source_local_v2").value;
    }

    var local_url = document.getElementById("source_url_v").checked;
    if(local_url == true){
     // alert('yes');
     var local_val = document.getElementById("source_url_v").value;
     document.getElementById("url_v").style.display = 'block';
    }

    //var local_code = document.getElementById("source_code_v").checked;
    var local_code = false;
    if(local_code == true){

     var local_val = document.getElementById("source_code_v").value;

    }

    displayContainer(local_val);

    var local_code = document.getElementById("source_code_a").checked;

    if(local_code == true){

     var local_vala = document.getElementById("source_code_a").value;

    }

    var local_urla = document.getElementById("source_url_a").checked;

    if(local_urla == true){

     var local_vala = document.getElementById("source_url_a").value;

    }

    var local_locala = document.getElementById("source_local_a2").checked;

    if(local_locala == true){

     var local_vala = document.getElementById("source_local_a2").value;

    }



    displayContainerAudio(local_vala);







    var local_coded = document.getElementById("source_url_d").checked;



    if(local_coded == true){

     var local_vala = document.getElementById("source_url_d").value;

    }
    var local_locald = document.getElementById("source_local_d2").checked;

   // alert(local_locald);

    if(local_locald == true){
     var local_vala = document.getElementById("source_local_d2").value;
    }
    // alert(local_locald);

    displayContainerDoc(local_vala);

    var local_urlf = document.getElementById("source_url_f").checked;



    if(local_urlf == true){



     var local_vala = document.getElementById("source_url_f").value;







    }



    var local_localf = document.getElementById("source_local_f2").checked;



    if(local_localf == true){



     var local_vala = document.getElementById("source_local_f2").value;







    }



    displayContainerFile(local_vala);



}



</script>



<script type="text/javascript">
var type='';
  function alldisable(type)
            {
             document.getElementById("videoblock").style.display = 'none';
             document.getElementById("audioblock").style.display = 'none';
             document.getElementById("imageblock").style.display = 'none';
              document.getElementById("urlblock").style.display = 'none';
              document.getElementById("docsblock").style.display = 'none';
              document.getElementById("fileblock").style.display = 'none';
              document.getElementById("textblock").style.display = 'none';

            }

            function changeType(type)
          {

            alldisable(type);

               if(type == 'text')
                {

                 /* $('#description').redactor({
                      focus: true,
                      imageUpload: window.location.origin+'/admin/medias/getImage',
                          
                    });*/
                } 

            document.getElementById(type+"block").style.display = 'block';

          }


function displayContainerFile(conval)
                {
         
             if(conval=='url')
                {
                document.getElementById("url_f").style.display = 'block';
                document.getElementById("localfile_f1").style.display = 'none';
                }



             if(conval=='local')
             {

              document.getElementById("url_f").style.display = 'none'
              document.getElementById("localfile_f1").style.display = 'block';
            }



    }



function displayContainerDoc(conval)
    {
         if(conval=='url')
         {
          document.getElementById("url_d").style.display = 'block';
          document.getElementById("localfile_d1").style.display = 'none';
          document.getElementById("localfile_d2").style.display = 'none';
          document.getElementById("localfile_d3").style.display = 'none';
          }

         if(conval=='local')
          {
            document.getElementById("url_d").style.display = 'none'



           document.getElementById("localfile_d1").style.display = 'block';



           document.getElementById("localfile_d2").style.display = 'block';



           document.getElementById("localfile_d3").style.display = 'block';



         }



    }







    function displayContainerAudio(conval)



    {



         if(conval=='code')



         {



           document.getElementById("code_a").style.display = 'block';



           document.getElementById("url_a").style.display = 'none';



         //  document.getElementById("localfile_a1").style.display = 'none';



           document.getElementById("localfile_a2").style.display = 'none';



       //    document.getElementById("localfile_a3").style.display = 'none';



         }



         if(conval=='url')



         {



           document.getElementById("code_a").style.display = 'none';



           document.getElementById("url_a").style.display = 'block';



        //   document.getElementById("localfile_a1").style.display = 'none';



           document.getElementById("localfile_a2").style.display = 'none';



         //  document.getElementById("localfile_a3").style.display = 'none';



         }



         if(conval=='local')



         {



           document.getElementById("code_a").style.display = 'none';



           document.getElementById("url_a").style.display = 'none';



          // document.getElementById("localfile_a1").style.display = 'block';



           document.getElementById("localfile_a2").style.display = 'block';



          // document.getElementById("localfile_a3").style.display = 'block';



         }



    }







    function displayContainer(conval)



    {



         //alert(conval);



         if(conval=='code')



         {



            document.getElementById("code_v").style.display = 'block';



            document.getElementById("url_v").style.display = 'none';



            document.getElementById("url_v1").value = '';



            document.getElementById("localfile_v1").style.display = 'none';



         //   document.getElementById("localfile_v2").style.display = 'none';



      //      document.getElementById("localfile_v3").style.display = 'none';



         }



        if(conval=='url')



         {



            document.getElementById("code_v").style.display = 'none';



            document.getElementById("code_v1").value = '';



            document.getElementById("url_v").style.display = 'block';



            document.getElementById("localfile_v1").style.display = 'none';



          //  document.getElementById("localfile_v2").style.display = 'none';



          //  document.getElementById("localfile_v3").style.display = 'none';



         }



         if(conval=='local')



         {



            document.getElementById("code_v").style.display = 'none';



            document.getElementById("url_v").style.display = 'none';



            document.getElementById("localfile_v1").style.display = 'block';



           // document.getElementById("localfile_v2").style.display = 'block';



        //    document.getElementById("localfile_v3").style.display = 'block';



         }







    }











</script>



<script type="text/javascript">



function change_radio_code() {



  if(document.tform.type.value == 'video')



    adding_ext = '_v';



  if(document.tform.type.value == 'audio')



    adding_ext = '_a';



  if(document.tform.type.value == 'docs')



    adding_ext = '_d';



  if(document.tform.type.value != 'docs')







   document.getElementById('source_code'+adding_ext).checked = 'checked';







  document.getElementById('source_url'+adding_ext).checked = '';



  //document.getElementById('source_local'+adding_ext).checked = '';



  document.getElementById('source_local'+adding_ext+'2').checked = '';



}



function change_radio_url() {



  if(document.tform.type.value == 'video')



    adding_ext = '_v';



  if(document.tform.type.value == 'audio')



    adding_ext = '_a';



  if(document.tform.type.value == 'docs')



    adding_ext = '_d';



  if(document.tform.type.value == 'file'){



    document.getElementById('filePreview').innerHTML="<a href='"+document.getElementById('url_f').value+"'>Download</a>";



    adding_ext = '_f';



  }



  if(document.tform.type.value != 'docs' && document.tform.type.value != 'file')



      document.getElementById('source_code'+adding_ext).checked = '';



  document.getElementById('source_url'+adding_ext).checked = 'checked';



  //document.getElementById('source_local'+adding_ext).checked = '';



  document.getElementById('source_local'+adding_ext+'2').checked = '';



}







 function change_radio_local() {



  if(document.tform.type.value == 'video')



    adding_ext = '_v';



  if(document.tform.type.value == 'audio')



    adding_ext = '_a';



  if(document.tform.type.value == 'docs')



    adding_ext = '_d';



  if(document.tform.type.value == 'file'){



    adding_ext = '_f';



    document.getElementById('filePreviewList').href=document.getElementById('filesFolder').innerHTML+"/"+document.getElementById('localfile_f').value;



    document.getElementById('filePreviewList').style.visibility="visible";







  }



  if(document.tform.type.value != 'docs' && document.tform.type.value != 'file')



      document.getElementById('source_code'+adding_ext).checked = '';



  document.getElementById('source_url'+adding_ext).checked = '';



  document.getElementById('source_local'+adding_ext+'2').checked = 'checked';



}

</script>
<div class="main-container">
<?php

$attributes = array('class' => 'tform', 'id' => 'upload_file','name' => 'tform');
echo ($updType == 'create') ? form_open_multipart(base_url().'admin/medias/create', $attributes) : form_open_multipart(base_url().'admin/medias/edit/'.$id, $attributes);
?>

</div>



<div class="field_container">
<div class="row">
<div class="col-md-6 col-md-6 col-sm-6 col-xs-6" style="width: 100%;">    
    <div class="panel panel-primary primary-border" data-collapsed="0">
    
      <div class="panel-heading">
       
      </div>
      
      <div class="panel-body form-body">
        
        <form role="form" class="form-horizontal form-groups-bordered">
          
                    <div class="form-group form-border" style="display: none;">
            
                        <label class='col-sm-12 control-label field-title' for="type">Type <span class="required">*</span>
<!--                           <p>(Please select your Type)</p>
 -->                        </label>
                      <div class="col-sm-12">
              
                        <select class="form-control form-height" size="1" name="type" id="type">

                            <option value="file">File</option>
                          

                          </select>

          
                        <span class="error"><?php echo form_error('type'); ?></span>
                    </div>
          </div>
                    
                    
          <div class="form-group form-border" style="padding-top:0!important;">
            
                 <label class='col-sm-12 control-label field-title' for="name">Title<span class="required">*</span>
                    <!-- <p>(e.g. Innovation Management - Please give a short and clear title)</p> -->
                 </label>
                <div class="col-sm-12">
                  
                  <input id="name" type="text" class="form-control form-height" placeholder="Name" name="name" maxlength="256" onblur="return check_name('name');" value="<?php echo set_value('name', (isset($media->alt_title)) ? $media->alt_title : ''); ?>"  />
                  <small id="ajax"></small>

   

                <span class="error"><?php echo form_error('name'); ?></span>
                </div>
        </div>
                    
          
          <div class="form-group form-border top-padding">
            
            <label class='col-sm-12 control-label field-title' for='category_id'><?php echo lang('web_category')?> <span class="required">*</span>
             
            </label>
            <div class="col-sm-12">
              
                        <select name='category_id' id='category_id' class="form-control form-height">

                            <option value="">Select Category</option>

                              <?php foreach ($categories as $category): ?>

                                          <option value='<?php echo $category->id?>' <?php echo  preset_select('category_id', $category->id, (isset($media->catid)) ? $media->catid : $parent_id  ) ?>><?php echo $category->name?></option>

                              <?php endforeach ?>

                       </select>



                        <span class="error"><?php echo form_error('category_id'); ?></span>
          </div>
          <a href="<?php echo base_url(); ?>admin/mcategories/createcategory" id="cropcategory" class="newcat_pop btn btn-success btn-border-blue" style="margin-left: 20px;">Create New Category</a>
            
          </div>
                   
          <div class="form-group form-border chkbox_top_padding" style="display: none;">
            <div class="col-sm-12">
            <div class="grey-background">
              <div class="checkbox">
                <input id="published" type="checkbox" name="published" value='1' <?php echo ($this->input->post('published') == '1') ? "checked" : (isset($media->publish)) && $media->publish == '1' ? "checked" : ''; ?> <?php echo $updType == 'create' ? 'checked':''; ?> />





            <label class='labelforminline dark_label' for='published'> Publish </label>


              </div>
              
            </div>
            </div>
          </div>
                    
          
                
                    
          
          
            
   <?php
    
    $vmedia = (strtolower($mediatypeval)=='video')? '' : 'none'; ?>

    <div id="videoblock" style="display: block; margin: 20px 0 0 0;">

  
<div class="col-md-12">
    
    <div class="panel panel-primary">
    
      <div class="panel-heading">
        <div class="panel-title">
        Select File Source
        </div>
           
        
      </div>
            
      
      <div class="panel-body">
        
        <fieldset class="adminform form-horizontal form-groups-bordered">
     <div class="form-group">
                    
           
                    
          <div id="localfile_v1" style='display:block'>
            <label for="field-1" class="col-sm-3 control-label">Upload :</label>
            <div class="col-sm-5">

                <div id="videoUploader">

                  <div class="qq-uploader">
                      <div class="qq-upload-button" style="position: relative; direction: ltr;">
                          <input type="file" name="file_f" id="file_f" class="upload_btn">    
                        <?php  $videopath = (isset($media->local)) ? $media->local : ''; ?>
                          <input type="hidden" value="<?php echo ($this->input->post('videopath')) ? $this->input->post('videopath') : $videopath ?>" name="videopath" id="videopath">

                      </div>
                      (Allowed file types: rar, zip, doc, docx, ppt, pptx, pdf, txt, jpg, png, gif, bmp,swf, mp3, avi, mp4, mpeg) 
                  </div>


                </div>
                 <div id="video_media">
                
                   <script type="text/javascript">
                  //    jQuery('#video_media').load("<?php echo base_url();?>public/uploads/videos"+<?php echo $media->media_title; ?>);
                   </script>

                 </div>

                 <font color="#FF0000"></font>
                 </fieldset>
        
      </div>
    
    </div>
  
  </div>


</div>

  <!--audio section starts here-->



    <?php 
    
   $amedia = (strtolower($mediatypeval)=='audio')? '' : 'none'; ?>



  <div id="audioblock" style="display:none;"></div>



  <!--documents section starts here-->



   <!-- <div id="docsblock"  style="display:<?php echo ($mediatypeval=='docs')? '' : 'none';?>;">   -->



   <?php 
//echo"<pre>";
//print_r($media);
   
   $dmedia = ($mediatypeval=='docs' || $mediatypeval=='Document')? '' : 'none'; ?>



  <div id="docsblock" style="display:none;"></div>



  <!--url section starts here-->







  <!--<div id="urlblock"  style="display:<?php echo ($mediatypeval=='url')? '' : 'none';?>;"> -->



    <?php $umedia = ($mediatypeval=='url')? '' : 'none'; ?>



  <div id="urlblock" style="display:<?php echo ($this->input->post('type')== 'url') ? 'block' : $umedia ?>"></div>




    <?php 
    //echo $mediatypeval;
    //echo $imgmedia = (strtolower($mediatypeval)=='image')? '' : 'none'; ?>



  <div id="imageblock" style="display:none;"></div>



  <!--text section starts here-->



  <!--<div id="textblock"  style="display:<?php echo ($mediatypeval=='text')? '' : 'none';?>;">-->



     <?php $textmedia = ($mediatypeval=='text')? '' : 'none'; ?>



  <div id="textblock" style="display:<?php echo ($this->input->post('type')== 'text') ? 'block' : $textmedia; ?>">



    


<div class="col-md-12">
    
    <div class="panel panel-primary" data-collapsed="0">
    
      <div class="panel-heading">
        <div class="panel-title">
          Enter text
        </div>
      
      </div>
      
      <div class="panel-body">
        <fieldset class="adminform form-horizontal form-groups-bordered">
        <!--<form role="form" class="form-horizontal form-groups-bordered">-->
  
          <table class="adminform">



      <tbody>



        <tr>



        <td width="33%">

              <label class='labelform' for="description"><?php echo lang('web_description')?> <span class="required">*</span></label>

          </td>



          <td>
            <!--<textarea id="description" name="description"  /><?php echo ($this->input->post('description')) ? $this->input->post('description') : ((isset($media->description)) ? $media->description : ''); ?></textarea>-->
            <textarea id="description" name="description"  /><?php echo ($this->input->post('description')) ? $this->input->post('description') : ((isset($media->code)) ? $media->code : ''); ?></textarea>
                        <!--<textarea name="description" id="description" class="stinput" rows="6"></textarea>-->

                      <?php echo form_error('description'); ?>

          </td>

        </tr>

      </tbody>

      </table>
                                
                    
        <!--</form>-->
        </fieldset>
      </div>
    
    </div>
  
  </div>

  

  </div>

  <!--file section start here-->

   <!-- <div id="fileblock"  style="display:<?php echo ($mediatypeval=='file')? '' : 'none';?>;"> -->
    

    <?php 
    
    $filemedia = ($mediatypeval=='Flash')? '' : 'none'; ?>

    <div id="file_media">
        <?php if(isset($media->media_title)){ 

          $exploded = explode('.',$media->media_title);
                        $img = array('jpg','jpeg','gif','png');
                        $video = array('mp4','mov','ogg','avi','flv','wmv','mpeg');
                        if(in_array(end($exploded), $img))
                        {
                       ?>
                        <img width='341' height='auto' src="<?php echo base_url() ?>public/uploads/files/<?php echo $media->media_title ?>">
                    <?php  }
                      else if(in_array(end($exploded), $video)){ ?>
                       <video  controls class="playerio plyr--video vplyr" id="playerio_1" preload="metadata">
                        <source src="<?php echo base_url();?>public/uploads/videos/<?php echo $media->media_title; ?>#t=05,00" type="video/mp4">
                      </video>
                  <?php    }
                    else echo 'Media source:'.$media->media_title;
                   } ?>
    </div>
  <div id="fileblock" style="display:none;">

    
       
        <div class="col-md-12">
    
    <div class="panel panel-primary" style="border:none;" data-collapsed="0">
    
      <div class="panel-heading">
        <div class="field-title">
          Select file source
        </div>
        
      
      </div>
      
      <div class="panel-body panel-gap">
        <fieldset class="adminform form-horizontal form-groups-bordered">
       

                        </div> 
                    </div>
                    
        <!--</form>-->
                </fieldset>
        
      </div>
    
    </div>
  
  </div>

  

  </div>
                    
          
          
          <div class="form-group form-border" style="padding-top: 2.5%!important;">
            <div class="col-sm-5">
              
                       
      <a>

      <?php echo form_submit( 'submit', ($updType == 'edit') ? "Update" : "Update", (($updType == 'create') ? "id='submit' class='btn btn-default btn-green'" : "id='submit' class='btn btn-default btn-green'")); ?>

      </a>



      <a href='<?php echo base_url(); ?>admin/medias<?php //echo $parent_id?>/<?php //echo $page?>' class='btn btn-red btn-dark-grey'><span class="icon-32-cancel"> </span>Cancel</a>

            </div>
          </div>
        </form>
        
      </div>
    
    </div>
  
  </div>

  <!--Main fieldset-->

    <!--End Main fieldset-->
</div>
</div>
</div>

<?php //echo form_hidden('page',set_value('page', $page)) ?>

<?php echo form_hidden('parent_id',set_value('parent_id', $parent_id)) ?>

<?php if ($updType == 'edit'): ?>

<?php echo form_hidden('id',$media->id) ?>

<?php endif ?>

<?php echo form_close(); ?>

<div>


<!-- tool tip script -->

<script type="text/javascript">

//$(document).ready(function(){
//
//  $('.tooltipicon').click(function(){
//
//  var dispdiv = $(this).attr('id');
//
//  $('.'+dispdiv).css('display','inline-block');
//
//  });
//
//  $('.closetooltip').click(function(){
//
//  $(this).parent().css('display','none');
//
//  });
//
//  });
jQuery(document).ready(function(){
	jQuery('.tooltipicon').mouseenter(function(){		
	var dispdiv = jQuery(this).attr('id');
	jQuery('.'+dispdiv).css('display','inline-block');
	});
	jQuery('.tooltipicon').mouseleave(function(){		
	var dispdiv = jQuery(this).attr('id');
	jQuery('.'+dispdiv).css('display','none');
	});
	});
  </script>


<link rel="stylesheet" href="<?php echo base_url(); ?>public/colorbox-master/example1/colorbox.css" />

<script src="<?php echo base_url(); ?>public/colorbox-master/jquery.colorbox.js"></script>
<script>
    var $j = jQuery.noConflict();
    $j(document).ready(function(){
    //Examples of how to assign the Colorbox event to elements

    //$j(".iframe").colorbox({iframe:true, width:"800px", height:"600px"}); 
    $j(".newcat_pop").colorbox({
    iframe:true,
    width:"500px", 
    height:"70%",
    fadeOut:500,
    fixed:true,
    reposition:true,  
    })
     });
</script>
<script>
jQuery(document).ready(function(){
  $j('#upload_file').submit(function()
{
  var name = $j('#name').val();
  var cat = $j('#category_id').val();
  var file = $j('#file_f').val();
  if(name && cat  && file)
  {
   $j("input[type='submit']", this)
  .val("Please Wait...")
  .attr('disabled', 'disabled');
  return true;
  }

});
// $j("#submit").click(function(){
//    var name = $j('#name').val();
//    var cat = $j('#category_id').val();
//    var file = $j('#file_f').val();
//    if(name && cat &&alert('yes');
//    $j("#submit").attr("disabled", true);
//    }
// });
});




jQuery(document).on('ready', function(){
  const options = {
    settings: [''],
    volume: 0.5,
};
    
    str = new Plyr('#playerio_1', options);

  });

  
</script>