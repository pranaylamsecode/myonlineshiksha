<link rel="stylesheet" type="text/css" href="/public/css/courses_css/courses_form.css">

<div class="main-container">
	<style>
		.coup_course{
			cursor: pointer;
			list-style-type: none;
			padding: 10px;
			font-size: 14px;
		}
		.coup_course:hover{
		   background-color: #edeef0;
		}
		#sel_course{
		    /*border: 2px solid #eee;*/
		    position: relative;
		    margin-top: 30px;
		    margin-bottom: 30px;
		}?>

		.txt_list {
		    padding: 6px;
		    background-color: #9a9a9a;
		    border-radius: 15px;
		    color: white;
		    margin: 15px;
		    margin-right: 5px;
		}
		div#sel_course a {padding: 6px;background-color: #9a9a9a;border-radius: 15px;color: white;margin: 1px 1px;display: inline-block;font-size: 14px;
}
	</style>
<?php



$attributes = array('class' => 'tform', 'id' => '');



echo ($updType == 'create') ? form_open(base_url().'admin/promocodes/create', $attributes) : form_open(base_url().'admin/promocodes/edit/'.$id, $attributes);



?>
<?php function get_timeago( $ptime )
{
    $estimate_time = time() - $ptime;
    if( $estimate_time < 1 )
    {
        return 'Just Now';
    }

    $condition = array( 
                12 * 30 * 24 * 60 * 60  =>  'year',
                30 * 24 * 60 * 60       =>  'month',
                24 * 60 * 60            =>  'day',
                60 * 60                 =>  'hour',
                60                      =>  'minute',
                1                       =>  'second'
    );

    foreach( $condition as $secs => $str )
    {
        $d = $estimate_time / $secs;
        if( $d >= 1 )
        {
            $r = round( $d );
            return $r . ' ' . $str . ( $r > 1 ? 's' : '' ) . ' ago';
        }
    }
}  ?>


<div id="toolbar-box">

	<div class="m top_main_content">

		<div id="toolbar" class="toolbar-list">

			<div class="clr"></div>

		</div>

		<div class="col-sm-12 pagetitle generic" style="padding:0;">

        <h2><?php echo ($updType == 'create') ? 'Add Coupon' : 'Edit Coupon';?></h2>

        </div>

	</div>

</div>



<!--<link href="<?php echo base_url(); ?>public/css/bootstrap.min.css" rel="stylesheet" media="screen">-->



<link href="<?php echo base_url(); ?>public/css/datetimepicker.css" rel="stylesheet" media="screen">

<div class="field_container">
 <div class="row content">
<div class="col-md-6 col-md-6 col-sm-6 col-xs-6" style="width: 100%;">
		
		<div class="panel panel-primary primary-border" data-collapsed="0">
		
			<div class="panel-heading">
				
				<!-- <div class="panel-options">
					<a href="#sample-modal" data-toggle="modal" data-target="#sample-modal-dialog-1" class="bg"><i class="entypo-cog"></i></a>
					<a href="#" data-rel="collapse"><i class="entypo-down-open"></i></a>
					<a href="#" data-rel="reload"><i class="entypo-arrows-ccw"></i></a>
					<a href="#" data-rel="close"><i class="entypo-cancel"></i></a>
				</div> -->
			</div>
			
			<div class="panel-body form-body">
				
				<form role="form" class="form-horizontal form-groups-bordered">
	
					
                    
					
					<div class="form-group form-border" style="padding-top: 0!important;">
						<label for="field-1" class="col-sm-12 control-label field-title">Coupon code<font color="#FF0000">*</font>
							<p>Alpha-numeric characters only. e.g. CHRISTMAS101, 50OFF, DIWALI10

</p>
						</label>
						
						<div class="col-sm-12">
							<input type="text" class="form-control form-height" placeholder="Code" name="code" value="<?php echo set_value('code', (isset($promocodes->code)) ? $promocodes->code : ''); ?>">
								<span class="error"><?php echo form_error('code'); ?></span>
						</div>
					</div>
                   <div class="form-group form-border">
						<label for="field-1" class="col-sm-12 control-label field-title">Short description<font color="#FF0000">*</font></label>
						
						<div class="col-sm-12">
							
                             <input id="title" class="form-control form-height" type="text" name="title" maxlength="256" value="<?php echo set_value('title', (isset($promocodes->title)) ? $promocodes->title : ''); ?>" placeholder="Enter short description"  />



                        <span class="error"><?php echo form_error('title'); ?></span>
						</div>
					</div>

					<div class="form-group form-border" style="padding-top:2%!important;">
					  <div class="col-sm-12 Sel_div" >
							<label for="field-1" class="col-sm-12 control-label field-title">Coupon applied for</label>
							<div class="grey-background">
								<div style="display:inline;">
									<input class="coupon_for" name="coupon_for" type="radio" checked="" value="0" <?php echo ($this->input->post('coupon_for')) ? 'checked="checked"' : (isset($promocodes->coupon_for) && $promocodes->coupon_for == '0') ? 'checked="checked"' : ''?> name="coupon_apply">
									<span>All Over Site</span>
								</div>
								<div style="display:inline;padding-left:2%;">
									<input class="coupon_for" name="coupon_for" type="radio" value="1" <?php echo ($this->input->post('coupon_for')) ? 'checked="checked"' : (isset($promocodes->coupon_for) &&$promocodes->coupon_for == '1') ? 'checked="checked"' : '' ?> name="coupon_apply">
									<span>Selected Course</span>
								</div>
							</div>


					  </div>
                        
					</div>
				

<!-- search course -->
<div class="form-group form-border select_course" style="padding-top: 0!important; display: <?php echo (isset($promocodes->coupon_for) &&$promocodes->coupon_for == '1') ? 'block' : 'none' ?> ">
	<div class="col-sm-12">
		<input type="hidden" name="coupon_course" id="sel_course_id" value="<?php echo set_value('coupon_course', (isset($promocodes->coupon_course)) ? $promocodes->coupon_course : ''); ?>">	
		<div id="sel_course">
			<?php if($updType == 'edit'){
				$CI = & get_instance();

				if(isset($promocodes->coupon_course) && $promocodes->coupon_course != '')
				{
					$CI->load->model('admin/programs_model');
					$cou_list = $CI->programs_model->getProgramTitle($promocodes->coupon_course);
					if($cou_list){
						foreach ($cou_list as $list) {
				
							echo "<a href='javascript:void(0)' class='cut_ele' id='txt_".$list->id."' ><span class='txt_list' >".$list->name."</span>&times</a>";
						}
					}
				}
			} ?>
		</div>
		<input autocomplete="none" id="getlistitem1" type="text" name="searchtext" value="" class="form-control form-height" placeholder="Search a course for you" style="color:black;">
		<ul id="getitemlist1" style="display: none"></ul>
	</div>
</div>

					<div class="form-group form-border" style="padding-top: 0!important;">
						<label for="field-1" class="col-sm-12 control-label field-title">Number of times coupon can be used


							<p>Put numeric value only, leave empty if no limits.</p>
						</label>
						
						<div class="col-sm-12">
							<input type="number" value="<?php echo set_value('codelimit', (isset($promocodes->codelimit)) ? $promocodes->codelimit : ''); ?>" name="codelimit"  class="form-control form-height" placeholder="Usage limit">    
								<span class="error"><?php echo form_error('codelimit'); ?></span>
						</div>
					</div>
                    
					<div class="form-group form-border" style="padding-top:0%!important;">
						<label for="field-1" class="col-sm-12 control-label field-title">Discount <font color="#FF0000">*</font></label>
						
						<div class="col-sm-6">
							<input type="number" class="form-control form-height"  placeholder="Discount amount" value="<?php echo set_value('discount', (isset($promocodes->discount)) ? $promocodes->discount : ''); ?>" name="discount" size="10">
							<span class="error"><?php echo form_error('discount'); ?></span>
						</div>
						<div class="col-sm-6">
			    			<div class="grey-background">
								<input type="radio" checked="" value="0" <?php echo ($this->input->post('typediscount') == '0') ? 'checked="checked"' : (isset($promocodes->typediscount) && $promocodes->typediscount == '0') ? 'checked="checked"' : ''; ?> name="typediscount">
									<span> Fixed amount ($)</span>
								<input style="margin-left: 4%;" type="radio" value="1" <?php echo ($this->input->post('typediscount') == '1') ? 'checked="checked"' : (isset($promocodes->typediscount) && $promocodes->typediscount == '1') ? 'checked="checked"' : ''; ?> name="typediscount">
									<span> In percentage (%)</span>
							</div>
						</div>
                            
					<!-- tooltip area -->

						<!-- <span class="tooltipcontainer">

						<span type="text" id="discount-target" class="tooltipicon" title="Click Here"></span>

						<span class="discount-target  tooltargetdiv" style="display: none;" >

						<span class="closetooltip"></span>

						

						<?php echo lang('promoCode_fld_discount-amount');?>

                         

						</span>

						</span> -->

					<!-- tooltip area finish -->

                    </div>
					<div class="form-group form-border" style="padding-top:0%!important;">
					   <!--  <label class="col-sm-4 control-label field-title" style="background-color:#eeeeee">Coupon validity</label> -->
					    <legend>Coupon validity</legend>
						<label for="field-1" class="col-sm-12 control-label field-title">From :</label>
						
						<div class="col-sm-12">
						
                            <div class="controls input-append date form_datetime" data-link-field="dtp_input1">
								<?php

								$pdate = (isset($promocodes->codestart)) ? $promocodes->codestart : '';
								?>



						<input  type="text" class="form-control form-height" placeholder="Start publishing" maxlength="19" size="25" id="codestart"  value="<?php echo ($this->input->post('codestart')) ? $this->input->post('codestart') : $pdate; ?>"  name="codestart" <?php if($updType == 'edit') { echo 'readonly'; } ?> >




						</div>
						</div>
					</div>
                    
					
					<div class="form-group form-border">
						<label for="field-1" class="col-sm-12 control-label field-title">To :</label>
						
						<div class="col-sm-12">
							
                            <div class="controls input-append date form_datetime" data-link-field="dtp_input1">

							<?php

								$edate = (isset($promocodes->codeend)) ? $promocodes->codeend : '';
							?>



  						<input type="text" class="form-control form-height" placeholder="End publishing" maxlength="19" size="25" id="endpublish"  value="<?php echo ($this->input->post('codeend')) ? $this->input->post('codeend') : $edate; ?>"  name="codeend"  <?php if($updType == 'edit') { echo 'readonly'; } ?> >


<!-- tooltip area finish -->

  						</div>
						</div>
					</div>
                    
					
				
					<div class="form-group form-border" style="padding-top:2%!important;">
					  <div class="col-sm-12 Sel_div" >
			    		<div class="grey-background">
							<label class="col-sm-4 control-label field-title" style="padding:0!important;">Publish</label>
								<div style="display:inline;">
									<input type="radio" checked="" value="0" <?php echo ($this->input->post('published')) ? 'checked="checked"' : (isset($promocodes->published) && $promocodes->published == '0') ? 'checked="checked"' : ''?> name="published">
									<span>No</span>
								</div>
								<div style="display:inline;padding-left:2%;">
									<input type="radio" value="1" <?php echo ($this->input->post('published')) ? 'checked="checked"' : (isset($promocodes->published) &&$promocodes->published == '1') ? 'checked="checked"' : '' ?> name="published">
									<span>Yes</span>
								</div>


						</div>
					  </div>
                        
					</div>
                    
					<?php if(isset($promocodes->codelimit)) {?>
					
					<div class="form-group form-border" style="padding-top:2%!important;">
						                    <legend>Status</legend>

					 <div class="col-sm-12 Sel_div" >
			    	  <div class="grey-background">
						<label class="col-sm-4 control-label field-title">Total used</label>
						
						<div>
							<?php echo $promocodes->codeused; ?> <input style="visibility: hidden; width: 2px;">
						</div>


					</div>
					</div>
					</div>
                    <?php if($updType == 'edit'){ ?>
					<div class="form-group form-border" style="padding-top:2%!important;">
					  <div class="col-sm-12 Sel_div" >
			    	  <div class="grey-background">
						<label class="col-sm-4 control-label field-title">Usage left</label>
						
						<div>
							<?php echo (int)$promocodes->codelimit - (int)$promocodes->codeused; ?><input style="visibility: hidden; width: 2px;">
						</div>
                   

<!-- tooltip area finish -->
						
					</div>
                    </div>
                    </div>
					<?php } }



  			    else{  if($updType == 'edit'){?>
					
                    
                    <div class="form-group form-border" style="padding-top:2%!important;">
                      <div class="col-sm-12 Sel_div" >
			    	  <div class="grey-background">
							<label class="col-sm-4 control-label field-title">Usage left</label>
							<div>-<input style="visibility: hidden; width: 2px;"> </div>
					
					</div>
					</div>
					</div>

              			<?php }  }
              			if($updType == 'edit'){
              			?>

					<div class="form-group form-border" style="padding-top:2%!important;">
						<div class="col-sm-12 Sel_div" >
			    	      <div class="grey-background">
							<label class="col-sm-4 control-label field-title">Time left</label>
								<div>
								<?php
								$date1 = date_create(date('Y-m-d'));
								$date2 = date_create($promocodes->codeend);
								
								$diff=date_diff($date1,$date2);
								if($diff->invert == 0){
								echo $diff->format('%a days remaining');
								} else { echo "Expired!"; } ?>
									<input style="visibility: hidden; width: 2px;"></div>



					<!-- tooltip area finish -->
						
					</div>
                    </div>
                    </div>

					<?php } ?>
					
						<div class="col-sm-5" style="padding-top: 2.5%!important;">
						
			<?php echo form_submit( 'submit', ($updType == 'edit') ? 'Update' : 'Update', (($updType == 'create') ? "id='submit' class='btn btn-default btn-green'" : "id='submit' class='btn btn-default btn-green'") ); ?>





            <a href='<?php echo base_url(); ?>admin/promocodes/' class='btn btn-red btn-dark-grey'><span class="icon-32-cancel"> </span>Cancel </a>

						</div>
					
				</form>
				
			</div>
		
		</div>
	  </div>
	</div>

  </div>
</div>

 <link rel="stylesheet" href="//code.jquery.com/ui/1.11.2/themes/smoothness/jquery-ui.css">
  <script src="//code.jquery.com/jquery-1.10.2.js"></script>
  <script src="//code.jquery.com/ui/1.11.2/jquery-ui.js"></script>
 <script>
  $(function() {
    $( "#codestart" ).datepicker({ dateFormat: 'yy-mm-dd' }).val();
	$( "#endpublish" ).datepicker({ dateFormat: 'yy-mm-dd' }).val();
  });
  </script>




<?php if ($updType == 'edit'): ?>



<?php //echo form_hidden('promoid',set_value('promoid', $promoid)) ?>



	<?php echo form_hidden('id',$promocodes->id) ?>



<?php endif ?>







<?php echo form_close(); ?>





<!-- tool tip script -->

<script type="text/javascript">



jQuery(document).ready(function(){
	jQuery('.tooltipicon').mouseenter(function(){		
	var dispdiv = jQuery(this).attr('id');
	jQuery('.'+dispdiv).css('display','inline-block');
	});
	jQuery('.tooltipicon').mouseleave(function(){		
	var dispdiv = jQuery(this).attr('id');
	jQuery('.'+dispdiv).css('display','none');
	});
	});


$(document).on('keyup', '#getlistitem1', function(){
var input = $('#getlistitem1').val();
  
   $.ajax({

    url: "<?php echo base_url();?>category/getlistforcoupon",
            type: "POST",
        data: {input: input},
        success: function(data) { 
           if(data)
           {
            $('#getitemlist1').show();
            $('#getitemlist1').html(data);
           }
           else{
             $('#getitemlist1').hide();
             $('#getitemlist1').html();
           }
          },
          error: function(xhr, desc, err) {
                    console.log(xhr);
                },
      });
  });

	$(document).on('click', '.coup_course', function(){
		var text = $(this).text();
		var val = $(this).val();
		val1 = '"'+val+'"';
		var input_val = $('#sel_course_id').val();
		var arr = input_val.split(',');
		if($.inArray(val1, arr) == -1)
		{

			$('#sel_course').append("<a href='javascript:void(0)' class='cut_ele' id='txt_"+val+"' ><span class='txt_list' >"+text+"</span>&times</a>");
			$('#sel_course_id').val(input_val + val1+',');
		}
	});

	$(document).on('click', '.cut_ele' , function(){
		var id = $(this).attr('id');
				$(this).remove();

		var arr_id = id.split('_');
		var input_val = $('#sel_course_id').val();
		var new_str = input_val.replace('"'+arr_id[1]+'",', '');
		$('#sel_course_id').val(new_str);
	});

	</script>
	<style>
		.multi-button::after, .multi-button::before{
			color: #000!important;
		}
	</style>
	<script>
		$(document).on('click', '.coupon_for', function(){
			if($(this).val() == 1)
			{
				$('.select_course').show();
			}
			else{
				$('.select_course').hide();
			}
		})

	</script>

<!-- tool tip script finish -->
