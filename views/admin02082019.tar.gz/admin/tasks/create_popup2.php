

<style>



.error{
	color: red;
	font-size:13px;
	display: none;
}

.redactor-editor {
  min-width: 0px!important; 
}
.main-table {
  display: block!important;
  width: 100%!important;
}
</style>

<div class="main-container">
<?php


  $attributes = array('class' => 'tform', 'id' => 'frm_save_lecture');

echo form_open(base_url().'admin/tasks/save_lecture', $attributes);

?>


<div class="field_container">
<div class="row">
<div class="col-md-6 col-md-6 col-sm-6 col-xs-6 field_content" style="width: 100%;">
<div class="panel primary-border panel-primary" data-collapsed="0">
	
<div class="panel-body form-body main-table">
				
				<fieldset class="adminform form-horizontal form-groups-bordered" style="width:100%;">	
				
                    <div class="col-sm-6 no-padding">
              <label class='col-sm-12 control-label field-title'class='col-sm-12 no-left-padding control-label field-title' style="padding-left:0;" for="Lesson"><?php echo 'Lecture title:'//echo lang('web_name')?> <span class="required">*</span></label>
              <div class="col-sm-12 no-left-padding">

        <input id="name" class="form-control form-height" type="text" name="name" maxlength="256" value="<?php echo set_value('name', (isset($task->name)) ? $task->name : ''); ?>"  />

<!-- tooltip area -->
            <!-- <span class="tooltipcontainer">

            <span type="text" id="name-target" class="tooltipicon"></span>

            <span class="name-target  tooltargetdiv" style="display: none;" >

            <span class="closetooltip"></span>

          
            <?php echo lang('lecture_fld_name');?>

                        
            </span>

            </span> -->

<!-- tooltip area finish -->

        <span class="error"><?php echo form_error('name'); ?> </span>
                                
              </div>
            </div>            
           <div class="col-sm-3 no-padding">
              <label class='col-sm-12 control-label field-title'class='col-sm-12 no-left-padding control-label field-title' style="padding-left:0;" >
                Type 
              </label>
              <div class="col-sm-12 no-left-padding">
                <select id="lecture_type" name="lecture_type" class="form-control form-height"  size="1" >
                <option value="video_article" selected>Video and Article</option>
                <option value="article">Article</option>
                <option value="video">Video</option>
                <option value="pdf">Pdf</option>
                <option value="demo">Demo-Lecture</option>
                <!-- <option value="exam">Exam</option> -->
                </select>
              </div>
           </div>
           <div class="col-sm-3 no-padding">
             <label class='col-sm-12 control-label field-title'class='col-sm-12 no-left-padding control-label field-title' style="padding-left:0;" for="Lesson">
             Duration
             </label>
             <div class="col-sm-12 no-left-padding">

                <input id="lecture_duration" class="form-control form-height" type="text" name="lecture_duration" placeholder="ex.1:00 Hrs" value="10 Min" />
              </div>
           </div>


            <div class="form-group form-border" style="margin:0;padding-top: 0;">
            <div class="col-sm-12 no-padding">
          <div class="grey-background" style="display: -webkit-box;">
             <!--  <label class="col-sm-3 control-label"> </label> -->
             
                <div class="col-sm-1 no-padding" style="width:3%;">                
               <input id="published" type="checkbox" name="published" value='1' <?php echo ($this->input->post('published') == '1') ? 'checked="checked"' : (isset($task->published) && $task->published == '1') ? 'checked="checked"' : ''?> <?php echo $updType == 'create' ? 'checked="checked"':''; ?>/>
              </div>
               <label class='col-sm-11 no-padding control-label dark_label' style="padding-top: 2px;" for='active'>Publish <?//=lang('web_is_active')?> </label>


					
					</fieldset>
                    
      </div>
  </div>
</div>

	<ul id="sticky" class="main-content-btn" style="list-style: none; float: right;">



            <li id="toolbar-new" class="listbutton" style="float: left; margin-right: 10px;">
				  <a><input type="button" id='lecture_save' name="lecture_save" class='btn btn-success btn-green' value="Save" onclick="save_lecture();" ></a> 


			</li>
			
			<li id="toolbar-new" class="listbutton" style="float: left; margin-right: 10px;">



			<a href='#' class='btn btn-danger btn-dark-grey cross_icon' id="forward" style="color:#FFF;">Cancel</a>



			</li>            



			</ul>



	<?php echo form_hidden('parent_id',$parent_id) ?>	







<?php if ($updType == 'edit'): ?>



	<?php echo form_hidden('id',$day->id) ?>



<?php endif ?>


	
</div>
</div>


<?php echo form_close(); ?>


<script>

var optionsignin2 = { 
    beforeSend: function() 
    {
    	if($('#title').val()=='')
    	{
    		    		// $('#title').append('<span class="error">Please enter title</span> ');

    		$('#title').find('.error').text('Please enter title');
    		$('.error').show();
    		$('.error').fadeIn().delay(1000).fadeOut();
    		
    		return false;
    	}
    },
    uploadProgress: function(event, position, total, percentComplete) 
    {
        
 
    },
    success: function() 
    {
        
    
    },
    complete: function(response) 
    {  
    	var updType = "<?php echo $updType ?>";
    	if(updType=='edit')
    		var msg = "Chapter Successfully Edited";
    	else var msg = "Successfully created the chapter";

		     	$.alert({
    	
		    title: msg,
		    content: '',
		});
		   window.parent.location.href = "<?php echo base_url(); ?>admin/section-management/<?php echo $parent_id;?>";  	
        
    },
    error: function()
    {   
      alert('error');
       
 
    }
 
}; 
 
$("#chapter").ajaxForm(optionsignin2);

</script>