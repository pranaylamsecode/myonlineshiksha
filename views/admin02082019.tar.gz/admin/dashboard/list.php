<table width="100%"><tbody><tr><td valign="top"><table style="background-color:#FFFFFF !important;" class="adminform">
	<tbody><tr>
		<td>
<div style="width:500px; margin-left:20px;" id="cpanel">

	<div style="float:left;">
		<div class="icon">
        	<a href="#">
            	<img align="middle" border="0" name="" alt="Settings" src="components/com_guru/images/icons/settings.png">
				<span>Settings</span>
			</a>
		</div>
	</div>

	<div style="float:left;">
		<div class="icon">
			<a href="#">
				<img align="middle" border="0" name="" alt="Courses" src="components/com_guru/images/icons/courses.png">
				<span>Courses</span>
			</a>
		</div>
	</div>

	<div style="float:left;">
		<div class="icon">
			<a href="#">
				<img align="middle" border="0" name="" alt="Media" src="components/com_guru/images/icons/media.png">
					<span>Media</span>
			</a>
		</div>
	</div>

	<div style="float:left;">
		<div class="icon">
			<a href="#">
				<img align="middle" border="0" name="" alt="Quizes" src="components/com_guru/images/icons/quizzes.png">
					<span>Quizes</span>
			</a>
		</div>
	</div>

	<div style="float:left;">
		<div class="icon">
			<a href="#">
				<img align="middle" border="0" name="" alt="Students" src="components/com_guru/images/icons/students.png">
                    <span>Students</span>
			</a>
		</div>
	</div>

	<div style="float:left;">
		<div class="icon">
			<a href="#">
				<img align="middle" border="0" name="" alt="Students" src="components/com_guru/images/icons/teachers.png">
                    <span>Teachers</span>
			</a>
		</div>
	</div>

	<div style="float:left;">
		<div class="icon">
			<a href="#">
				<img align="middle" border="0" name="" alt="Orders" src="components/com_guru/images/icons/orders.png">
					<span>Orders</span>
			</a>
		</div>
	</div>

	<div style="float:left;">
		<div class="icon">
			<a href="#">
				<img align="middle" border="0" name="" alt="Languages" src="components/com_guru/images/icons/language.png">
                    <span>Languages</span>
			</a>
		</div>
	</div>

	<div style="float:left;">
		<div class="icon">
			<a href="#">
				<img align="middle" border="0" name="" alt="Languages" src="components/com_guru/images/icons/payment.png">
                    <span>Subscriptions</span>
			</a>
		</div>
	</div>

	<div style="float:left;">
		<div class="icon">
			<a href="#">
				<img align="middle" border="0" name="" alt="Languages" src="components/com_guru/images/icons/email.png">
                    <span>System Emails</span>
			</a>
		</div>
	</div>

	<div style="float:left;">
		<div class="icon">
			<a href="#">
				<img align="middle" border="0" name="" alt="Languages" src="components/com_guru/images/icons/payment.png">
                    <span>Payment Plugins</span>
			</a>
		</div>
	</div>

	<div style="float:left;">
		<div class="icon">
			<a href="#">
				<img align="middle" border="0" name="" alt="Promo Codes" src="#">
					<span>Promo Codes</span>
			</a>
		</div>
	</div>

	<div style="float:left;">
		<div class="icon">
			<a target="_blank" href="#">
				<img align="middle" border="0" name="" alt="Forum" src="components/com_guru/images/icons/forum.png">
					<span>Forum</span>
			</a>
		</div>
	</div>

	<div style="float:left;">
		<div class="icon">
			<a target="_blank" href="#">
				<img align="middle" border="0" name="" alt="Support" src="#">
					<span>Support</span>
			</a>
		</div>
	</div>

	<div style="float:left;">
		<div class="icon">
			<a href="#">
				<img align="middle" border="0" name="" alt="About" src="#">
					<span>About</span>
			</a>
		</div>
	</div>

	<div style="float:left;">
		<div class="icon">
			<a target="_blank" href="http://www.ijoomla.com">
				<img align="middle" border="0" name="" alt="iJoomla.com" src="#">
					<span>iJoomla.com</span>
			</a>
		</div>
	</div>
</div>
		</td>
	</tr>
</tbody></table></td></tr></tbody></table>