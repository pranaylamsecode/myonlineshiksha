<?php
echo 'sample-register-form.php file';
exit('ram');
?>