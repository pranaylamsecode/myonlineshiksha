<div class="main-content"> 
       <!-- TS14420388514964: Xenon - Boostrap Admin Template created by Laborator / Please buy this theme and support the updates --> 
       <div class="page-error-404"> <div class="error-symbol"> <i class="entypo-database"></i> </div>
               <div class="error-text"> 
                       <h2>Database</h2> <p>Error found!</p> 
                       <br>
                       Mail sent to administrator
               </div> 
       <hr> 
               <div class="error-text">
               Search Pages:
               <br> <br> 
                       <div class="input-group minimal"> 
                               <div class="input-group-addon"> 
                               <i class="entypo-search"></i> 
                               </div> 
                       <input type="text" class="form-control" placeholder="Search anything..."> 
                       </div> 
               </div> 
       </div>
</div>